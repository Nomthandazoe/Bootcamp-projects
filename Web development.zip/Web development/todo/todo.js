var app = angular.module("myList", []);

app.controller("TodoListController", function(){
    var todoList = this;
    todoList.todos = ['Waterplants', 'Sleep'];
});
